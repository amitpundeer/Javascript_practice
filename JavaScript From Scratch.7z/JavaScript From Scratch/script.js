//Regular Expressions

let str = 'The quick brown fox jumps over the lazy dog';

let offset = str.search(/\b[a-z]{5}\b/);

alert(offset);