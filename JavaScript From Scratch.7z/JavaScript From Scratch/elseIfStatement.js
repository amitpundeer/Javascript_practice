//
//Program flow
//

//if statements
var ageAsString = prompt("What is your age?","");
var age = Number(ageAsString);

if(age < 40)
{
  alert("You are so young!");
}
else if(age == 100){
  alert("Immortal!!.");
}
else
{
  alert("Don't worry, you're young at heart.");
}

alert("Thank You!");