//hoisting
//hoist variable declaration to the top and
//function declaration to the top

var z = add(3,4);

function add(x, y)//function declaration is hoisted to the top of the page.
{
  return x+y;
}

output.textContent = z;