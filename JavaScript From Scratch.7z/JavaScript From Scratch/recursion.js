//recursion

let answer =document.getElementById('output');

//recursive function to calculate num^exp
function fact(num, exp)
{
  if(exp === 1)
    return num;
  return num * fact(num, exp-1);
}


//Non-Recursive Definition
function nonRecursiveFunc(num, exp)
{
  let ans=1;
  
  for(let i = 0; i < exp; i++)
  {
      ans = ans * num; 
  }//end-of-for
  
  return ans;
}//end-of-func


answer.innerHTML = nonRecursiveFunc(2,6);