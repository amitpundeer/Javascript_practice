Topic :- Javascript basics practice
Course:- JavaScript From Scratch by Jesse Liberty
