//function and scope

//braces doesn't create scope.
//functions create scope.

//Example 1:
var constant=32

function celsiusToFarenheit(temprature)
{
  var farenheitTemp = temprature * 9/5 + constant;
  return farenheitTemp;
}


output.textContent = celsiusToFarenheit(100);//works
//output.textContent = farenheitTemp;//Error

//Example 2:
var x=15;

if(x < 20)
{
  var y = x;
}

var z = y;//works
//only thing that create scopes in javascript is function.

output.textContent = z;