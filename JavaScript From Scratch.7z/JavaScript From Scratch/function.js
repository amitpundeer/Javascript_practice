add(x, y)
{
  var z = x+y;
  return z;
}

add();
