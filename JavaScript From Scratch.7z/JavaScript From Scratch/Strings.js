//Strings-1

let str1 ='The quick brown fox jumps over the "lazy" dog';
let str2 ="The quick brown fox jumps over the \"lazy\" dog";
let str3 =`The quick brown 
                    fox jumps over
                                  the 'lazy' dog.`;
//alert(str1);
//alert(str2);
//alert(str3);

let str4 = 'and lived ever after.';

let newString = str1 + str4;

//alert(newString);

var myArray = newString.split(' ');

alert(myArray);

let indexOfBrown = str1.indexOf('brown');
let indexOfJumps = str1.indexOf('jumps');

let myFox = newString.slice(indexOfBrown, indexOfJumps);
alert(myFox);