//
//Program flow
//

var age = Number(prompt("What is your age?",""));
var result="";

var r = true;
var res = r || alert("bawa");

alert(res);