//Recursion

let answer =document.getElementById('output');

empty = [];
empty[0] = 1;
empty[1] = 2;

//alert(empty);

let primes = [1,2,3,5,7, 11];
let fifthprime = primes[4];

//alert(fifthprime);

let myArray = [1, "Amit", false];
let truth =  myArray[2];

//alert(truth);

let lengthOfArray = myArray.length;

//alert(lengthOfArray);



function range(max)
{
  let arr = [];
  for(let i = 0; i < max; i++)
    arr[i] = i * 2;
  return arr;
}

//alert(range(5));




//Arrays-2

function range(max) {
  let arr = [];
  for (let i = 0; i < max; i++) {
    arr.push(2 * i);
  }
  return arr;
} //end-of-function

let myArr = range(5);

for (let i = 0; i < myArr.length; i++) {
  alert(myArr[i]);
}//end-of-for