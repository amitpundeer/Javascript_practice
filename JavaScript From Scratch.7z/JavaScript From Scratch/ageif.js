//
//Program flow
//

//if statements
var ageAsString = prompt("What is your age?","");
var age = Number(ageAsString);

if(age < 40)
{
  alert("You are so young!");
}

alert("Thank You!");