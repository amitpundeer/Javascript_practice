//
//Program flow
//

//if statements
var age = Number(prompt("What is your age?",""));
var result="";

/*
while(age > 0)
{
  result = result + "Happy Birthday";
  age = age - 1;
}
*/

do
{
  result = result + "Happy Birthday";
  age = age - 1;
}while(age > 0)

alert(result);