//
//switch
//

var animal = "dog";

switch(animal)
{
  case "cat": alert("meow"); break;
  case "dog": alert("bark"); break;
  case "horse": alert("whinny"); break;
  
  default: alert("other animal"); break;
}

